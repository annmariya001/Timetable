# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('generate/', views.generate_timetable, name='generate_timetable'),
    path('courses/', views.course_list, name='course_list'),
    path('subjects/', views.subject_list, name='subject_list'),
]
