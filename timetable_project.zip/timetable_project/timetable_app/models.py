# models.py
from django.db import models

class Course(models.Model):
    name = models.CharField(max_length=100)

class Subject(models.Model):
    name = models.CharField(max_length=100)
    course = models.ForeignKey(Course, related_name='subjects', on_delete=models.CASCADE)

class Staff(models.Model):
    name = models.CharField(max_length=100)
    subjects = models.ManyToManyField(Subject)

class Timetable(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    day = models.CharField(max_length=10)  # e.g., 'Monday'
    period = models.CharField(max_length=10)  # e.g., 'Period 1'
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
