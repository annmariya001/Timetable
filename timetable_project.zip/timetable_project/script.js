function generateTimetable() {
    const timetable = document.getElementById('timetable');
    timetable.innerHTML = "<p>Timetable generated successfully!</p>";
}
